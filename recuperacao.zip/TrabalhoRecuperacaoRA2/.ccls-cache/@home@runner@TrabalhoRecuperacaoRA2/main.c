#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Definição da estrutura para armazenar informações de um carro
typedef struct Carro {
    char marca[21];
    char modelo[21];
    int ano;
    int quilometragem;
    float preco;
    struct Carro* prox;
} Carro;

// Função para criar um novo nó da lista
Carro* criarCarro(char* marca, char* modelo, int ano, int quilometragem, float preco) {
    Carro* novo = (Carro*)malloc(sizeof(Carro));
    strcpy(novo->marca, marca);
    strcpy(novo->modelo, modelo);
    novo->ano = ano;
    novo->quilometragem = quilometragem;
    novo->preco = preco;
    novo->prox = NULL;
    return novo;
}

// Função para inserir um carro na lista de forma ordenada pelo preço
void inserirOrdenado(Carro** head, Carro* novo) {
    if (*head == NULL || (*head)->preco >= novo->preco) {
        novo->prox = *head;
        *head = novo;
    } else {
        Carro* atual = *head;
        while (atual->prox != NULL && atual->prox->preco < novo->preco) {
            atual = atual->prox;
        }
        novo->prox = atual->prox;
        atual->prox = novo;
    }
}

// Função para ler o arquivo e preencher a lista
void lerArquivo(Carro** head, const char* nomeArquivo) {
    FILE* arquivo = fopen(nomeArquivo, "r");
    if (!arquivo) {
        perror("Erro ao abrir o arquivo");
        exit(1);
    }

    char marca[21], modelo[21];
    int ano, quilometragem;
    float preco;

    while (fscanf(arquivo, "%20s", marca) != EOF) {
        fgetc(arquivo); // Remove newline character
        fgets(modelo, 21, arquivo);
        modelo[strcspn(modelo, "\n")] = 0; // Remove newline character
        fscanf(arquivo, "%d %d %f", &ano, &quilometragem, &preco);
        fgetc(arquivo); // Remove newline character

        Carro* novo = criarCarro(marca, modelo, ano, quilometragem, preco);
        inserirOrdenado(head, novo);
    }

    fclose(arquivo);
}

// Função para exibir a lista completa de registros
void exibirLista(Carro* head) {
    Carro* atual = head;
    while (atual != NULL) {
        printf("------------------------------\n");
        printf("Marca: %s\n", atual->marca);
        printf("Modelo: %s\n", atual->modelo);
        printf("Ano: %d\n", atual->ano);
        printf("Quilometragem: %d\n", atual->quilometragem);
        printf("Preço: %.2f\n", atual->preco);
        printf("------------------------------\n");
        atual = atual->prox;
    }
}

// Função para exibir registros de uma marca específica
void exibirPorMarca(Carro* head, char* marca) {
    Carro* atual = head;
    while (atual != NULL) {
        if (strcmp(atual->marca, marca) == 0) {
            printf("------------------------------\n");
            printf("Marca: %s\n", atual->marca);
            printf("Modelo: %s\n", atual->modelo);
            printf("Ano: %d\n", atual->ano);
            printf("Quilometragem: %d\n", atual->quilometragem);
            printf("Preço: %.2f\n", atual->preco);
            printf("------------------------------\n");
        }
        atual = atual->prox;
    }
}

// Função para exibir registros dentro de um intervalo de preço
void exibirPorPreco(Carro* head, float precoMin, float precoMax) {
    Carro* atual = head;
    while (atual != NULL) {
        if (atual->preco >= precoMin && atual->preco <= precoMax) {
            printf("------------------------------\n");
            printf("Marca: %s\n", atual->marca);
            printf("Modelo: %s\n", atual->modelo);
            printf("Ano: %d\n", atual->ano);
            printf("Quilometragem: %d\n", atual->quilometragem);
            printf("Preço: %.2f\n", atual->preco);
            printf("------------------------------\n");
        }
        atual = atual->prox;
    }
}

// Função para inserir um novo registro de carro na lista
void inserirNovoCarro(Carro** head) {
    char marca[21], modelo[21];
    int ano, quilometragem;
    float preco;

    printf("Insira a marca do carro: ");
    scanf("%20s", marca);
    printf("Insira o modelo do carro: ");
    scanf(" %[^\n]%*c", modelo);
    printf("Insira o ano do carro: ");
    scanf("%d", &ano);
    printf("Insira a quilometragem do carro: ");
    scanf("%d", &quilometragem);
    printf("Insira o preço do carro: ");
    scanf("%f", &preco);

    Carro* novo = criarCarro(marca, modelo, ano, quilometragem, preco);
    inserirOrdenado(head, novo);
}

// Função para remover registros com quilometragem superior a um valor especificado
void removerPorQuilometragem(Carro** head, int quilometragem) {
    Carro* atual = *head;
    Carro* anterior = NULL;

    while (atual != NULL) {
        if (atual->quilometragem > quilometragem) {
            if (anterior == NULL) {
                *head = atual->prox;
            } else {
                anterior->prox = atual->prox;
            }
            Carro* temp = atual;
            atual = atual->prox;
            free(temp);
        } else {
            anterior = atual;
            atual = atual->prox;
        }
    }
}

// Função principal
int main() {
    Carro* carros = NULL;
    lerArquivo(&carros, "dados.txt");

    int opcao;
    do {
        printf("\nMenu:\n");
        printf("1. Exibir a lista completa de registros\n");
        printf("2. Exibir registros de uma marca específica\n");
        printf("3. Exibir registros dentro de um intervalo de preço\n");
        printf("4. Inserir um novo registro de carro na lista\n");
        printf("5. Remover registros com quilometragem superior a um valor\n");
        printf("6. Sair\n");
        printf("Escolha uma opção: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                exibirLista(carros);
                break;
            case 2: {
                char marca[21];
                printf("Insira a marca: ");
                scanf("%20s", marca);
                exibirPorMarca(carros, marca);
                break;
            }
            case 3: {
                float precoMin, precoMax;
                printf("Insira o preço mínimo: ");
                scanf("%f", &precoMin);
                printf("Insira o preço máximo: ");
                scanf("%f", &precoMax);
                exibirPorPreco(carros, precoMin, precoMax);
                break;
            }
            case 4:
                inserirNovoCarro(&carros);
                break;
            case 5: {
                int quilometragem;
                printf("Insira a quilometragem: ");
                scanf("%d", &quilometragem);
                removerPorQuilometragem(&carros, quilometragem);
                break;
            }
            case 6:
                printf("Saindo...\n");
                break;
            default:
                printf("Opção inválida! Tente novamente.\n");
                break;
        }
    } while (opcao != 6);

    // Liberar a memória alocada para a lista
    Carro* atual = carros;
    while (atual != NULL) {
        Carro* temp = atual;
        atual = atual->prox;
        free(temp);
    }

    return 0;
}
