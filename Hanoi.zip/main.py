#Função def para definir as variaveis dos pinos e quantidade de discos.
def Hanoi(n, A, B, C):
    # esse if é para quando a quantidade de discos for 1, o disco será movido e imprimira o movimento.
    if n == 1:
        print(f"Mova o disco de {A} para {C}")
        # esse else é para quando a quantidade de discos for maior que 1 o programa usara recursividade e o disco será movido e imprimira o movimento.
    else:
        Hanoi(n - 1, A, C, B)
        print(f"Mova o disco de {A} para {C}")
        Hanoi(n - 1, B, C, A)


#chamda da funcao para determinar a quatidade de discos. A quantidade minima de movimento seria 2**n - 1.
Hanoi(7, 'A', 'B', 'C')
