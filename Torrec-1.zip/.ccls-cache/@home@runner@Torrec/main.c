void Hanoi(int n, char A, char B, char C) {
  if (n == 1) {
    printf("Mova o disco de %c para %c\n", A, C);
  } else {
    Hanoi(n - 1, A, C, B);
    printf("Mova o disco de %c para %c\n", A, C);
    Hanoi(n - 1, B, C, A);
  }
}
int main() {
  Hanoi(7, 'A', 'B', 'C');
  return 0;
}